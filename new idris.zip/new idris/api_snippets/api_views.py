
# place this in your app/api_views.py
from rest_framework import viewsets, permissions
from .models import Product, Category, Order, OrderItem
from .serializers import ProductSerializer, CategorySerializer, OrderSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
import time

class IsOwnerOrAdmin(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        if request.user.is_staff:
            return True
        try:
            return obj.owner.user == request.user
        except Exception:
            return False

class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly, IsOwnerOrAdmin]

    def perform_create(self, serializer):
        serializer.save()

class CategoryViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer

class CartUpdateAPIView(APIView):
    permission_classes = [permissions.IsAuthenticated]
    def post(self, request):
        product_id = request.data.get('product_id')
        action = request.data.get('action')  # 'add'/'remove'/'set'
        quantity = int(request.data.get('quantity',1))
        customer = request.user.customer
        order, _ = Order.objects.get_or_create(customer=customer, complete=False)
        product = Product.objects.get(pk=product_id)
        order_item, created = OrderItem.objects.get_or_create(order=order, product=product)
        if action == 'add':
            order_item.quantity += quantity
            order_item.save()
        elif action == 'remove':
            order_item.quantity -= quantity
            if order_item.quantity <= 0:
                order_item.delete()
            else:
                order_item.save()
        elif action == 'set':
            if quantity <= 0:
                order_item.delete()
            else:
                order_item.quantity = quantity
                order_item.save()
        return Response({'ok': True}, status=status.HTTP_200_OK)
