
# place this in your app/tasks.py
from celery import shared_task
from django.core.mail import send_mail
from .models import Order

@shared_task
def send_order_confirmation_email(order_id):
    order = Order.objects.get(pk=order_id)
    subject = f'Order Confirmation #{order.id}'
    body = f'Thanks for your order! Total: {order.get_cart_price if hasattr(order, "get_cart_price") else "N/A"}'
    send_mail(subject, body, 'no-reply@example.com', [order.customer.email])
    return True
